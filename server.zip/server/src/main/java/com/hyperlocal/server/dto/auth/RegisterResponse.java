// package com.hyperlocal.server.dto.auth;

// import lombok.AllArgsConstructor;
// import lombok.Data;

// @Data
// @AllArgsConstructor
// public class RegisterResponse {
//     private String message;
    
// }
